```python
from Crypto.PublicKey import DSA


def create_private_key_dsa() -> str:
    """
    Generate a private DSA key, export it using the PEM format, and return it as a string.

    Returns:
        str: The DSA private key in PEM format.
    """
    key = DSA.generate(1024)
    pem = key.export_key('PEM')
    return pem.decode('utf-8')
```
